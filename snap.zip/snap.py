import requests,time,colorama,json,random,string
from colorama import Fore,init
init()
import certifi
import urllib3



print('''


   ___    ___                             
  / __\  / __\      ___ _ __   __ _ _ __  
 /__\// /__\//_____/ __| '_ \ / _` | '_ \ 
/ \/  \/ \/  \_____\__ \ | | | (_| | |_) |
\_____/\_____/     |___/_| |_|\__,_| .__/ 
                                   |_|    

-> بلاغات علي الحسابات السناب
-> اشتراك علي كل محاولة 300 مره 

---/// لاتجديد الاشتراك تواصل email ///---
       
       -> flaaah777@gmail.com 
       -> 2022 التحديث الجديد
------------------------------------------

''')



class report:
    def __init__(self):
        self.session = requests.Session()
        self.site_key = "6Ldt4CkUAAAAAJuBNvKkEcx7OcZFLfrn9cMkrXR8"
        self.url = "https://support.snapchat.com/"
        self.contents = open('config.json', 'r',encoding="latin-1",errors='ignore')
        self.data = json.load(self.contents)
        self.API_KEY = self.data['api_key']
        self.user = self.data['user']
        self.message = self.data['message']


    def captcha(self):
        try:
            captcha_id = self.session.post("http://2captcha.com/in.php?key={}&method=userrecaptcha&googlekey={}&pageurl={}".format(self.API_KEY, self.site_key, self.url)).text.split('|')[1]
            recaptcha_answer = self.session.get("http://2captcha.com/res.php?key={}&action=get&id={}".format(self.API_KEY, captcha_id)).text
            print(Fore.YELLOW+"[Solving] captcha solving...")
            while 'CAPCHA_NOT_READY' in recaptcha_answer:
                time.sleep(5)
                recaptcha_answer = self.session.get("http://2captcha.com/res.php?key={}&action=get&id={}".format(self.API_KEY, captcha_id)).text
            recaptcha_answer = recaptcha_answer.split('|')[1]
            return recaptcha_answer
        except Exception as e:
            print(e)


    def email_gen(self):
        ran = ('').join(random.choices(string.ascii_letters + string.digits, k=8))
        email = ran+"flaah9991@gmail.com"
        return email
   
    
    def report(self):
        emails = self.email_gen()
        answer1 = self.captcha()
        headers = {
            "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0",
            "Host":"support.snapchat.com",
            "Accept-Encoding":"gzip, deflate",
            "Cookie":"sc_at=v2|H4sIAAAAAAAAAE3GyREAIQgEwIiowuUazQY8ojD4/dqvjk/SsJNE6pCWgnKa08qjfaXE5LpNeTRDdw8D7lP+AR74ykdAAAAA",
            "Content-Type":"multipart/form-data; boundary=---------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw"
        }
        data ='''-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="key"

ts-reported-content-3
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="field-24335325"

{}
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="field-24380626"

{}
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="field-22808619"

{}
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="g-recaptcha-response"

{}
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw
Content-Disposition: form-data; name="answers"

5153567363039232,5763820408537088,6623032718917632
-----------------------------WebKitFormBoundarytAGRBVSJ92SMH4Lw--'''.format(emails,self.user,self.message,answer1)
        send_report = self.session.post("https://support.snapchat.com/en-US/api/v2/send",data=data,headers=headers , verify=False)
		
        if send_report.status_code==200:
            print(Fore.GREEN+"[Success] تم ارسال التقرير {}".format(self.user))
        else:
            print(Fore.RED+"[Error] لا يمكن إرسال التقرير")

if __name__ == "__main__":
    while True:
        start = report()
        start.report()
